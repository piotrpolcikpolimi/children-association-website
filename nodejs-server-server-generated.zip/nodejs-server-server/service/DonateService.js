'use strict';


/**
 * Donation form
 * A really simplified endpoint imitating donation service.
 *
 * amount Double 
 * message String 
 * no response value expected for this operation
 **/
exports.donatePOST = function(amount,message) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

