'use strict';


/**
 * Find a person by id
 * Returns a person with a given id
 *
 * id Long id of person to return
 * returns Person
 **/
exports.getPersonById = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "joining_date" : "2000-01-23",
  "testimonials" : [ {
    "testimonial" : "testimonial",
    "person_desc" : "person_desc",
    "photo" : "http://example.com/aeiou",
    "id" : 6
  }, {
    "testimonial" : "testimonial",
    "person_desc" : "person_desc",
    "photo" : "http://example.com/aeiou",
    "id" : 6
  } ],
  "role" : "role",
  "contact" : {
    "phone" : "phone",
    "starting_hours" : "starting_hours",
    "ending_hours" : "ending_hours",
    "email" : "email"
  },
  "name" : "name",
  "description" : "description",
  "location" : {
    "country_flag_ico n" : "country_flag_ico n",
    "country" : "country",
    "latitude" : 5.637376656633329,
    "name" : "name",
    "id" : 5,
    "longitude" : 2.3021358869347655
  },
  "id" : 0,
  "experience" : "experience",
  "event" : {
    "thumbnail" : {
      "thumbnail_desc" : "thumbnail_desc",
      "thumbnail" : "thumbnail",
      "id" : 6,
      "title" : "title"
    },
    "name" : "name",
    "location" : {
      "country_flag_ico n" : "country_flag_ico n",
      "country" : "country",
      "latitude" : 5.637376656633329,
      "name" : "name",
      "id" : 5,
      "longitude" : 2.3021358869347655
    },
    "id" : 1
  },
  "picture" : "http://example.com/aeiou"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * All available persons
 * Returns list of all the persons
 *
 * offset Long offset of the number of persons to return (optional)
 * limit Long the number of persons to return (optional)
 * returns List
 **/
exports.personsGET = function(offset,limit) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "joining_date" : "2000-01-23",
  "thumbnail" : {
    "thumbnail_desc" : "thumbnail_desc",
    "thumbnail" : "thumbnail",
    "id" : 6,
    "title" : "title"
  },
  "role" : "role",
  "meta" : {
    "total_number" : 1
  }
}, {
  "joining_date" : "2000-01-23",
  "thumbnail" : {
    "thumbnail_desc" : "thumbnail_desc",
    "thumbnail" : "thumbnail",
    "id" : 6,
    "title" : "title"
  },
  "role" : "role",
  "meta" : {
    "total_number" : 1
  }
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

