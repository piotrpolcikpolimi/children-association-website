'use strict';


/**
 * Find a service by id
 * Returns a service with a given id
 *
 * id Long id of service to return
 * returns Service
 **/
exports.getServiceById = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "cta" : "cta",
  "testimonials" : [ {
    "testimonial" : "testimonial",
    "person_desc" : "person_desc",
    "photo" : "http://example.com/aeiou",
    "id" : 6
  }, {
    "testimonial" : "testimonial",
    "person_desc" : "person_desc",
    "photo" : "http://example.com/aeiou",
    "id" : 6
  } ],
  "name" : "name",
  "description" : "description",
  "header_photo" : "http://example.com/aeiou",
  "practical_info" : "practical_info",
  "id" : 0,
  "center_activities" : "center_activities",
  "events" : [ {
    "thumbnail" : {
      "thumbnail_desc" : "thumbnail_desc",
      "thumbnail" : "thumbnail",
      "id" : 6,
      "title" : "title"
    },
    "name" : "name",
    "location" : {
      "country_flag_ico n" : "country_flag_ico n",
      "country" : "country",
      "latitude" : 5.637376656633329,
      "name" : "name",
      "id" : 5,
      "longitude" : 2.3021358869347655
    },
    "id" : 1
  }, {
    "thumbnail" : {
      "thumbnail_desc" : "thumbnail_desc",
      "thumbnail" : "thumbnail",
      "id" : 6,
      "title" : "title"
    },
    "name" : "name",
    "location" : {
      "country_flag_ico n" : "country_flag_ico n",
      "country" : "country",
      "latitude" : 5.637376656633329,
      "name" : "name",
      "id" : 5,
      "longitude" : 2.3021358869347655
    },
    "id" : 1
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * All available services
 * Returns list of all services
 *
 * returns List
 **/
exports.servicesGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "thumbnail" : {
    "thumbnail_desc" : "thumbnail_desc",
    "thumbnail" : "thumbnail",
    "id" : 6,
    "title" : "title"
  },
  "id" : 0
}, {
  "thumbnail" : {
    "thumbnail_desc" : "thumbnail_desc",
    "thumbnail" : "thumbnail",
    "id" : 6,
    "title" : "title"
  },
  "id" : 0
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

